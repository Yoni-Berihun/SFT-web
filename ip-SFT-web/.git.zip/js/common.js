(function (window) {
    const STORAGE_KEYS = {
        theme: "edufinance-theme",
        user: "edufinance-user",
        expenses: "edufinance-expenses",
        split: "edufinance-split-expenses",
        friends: "edufinance-friends",
        session: "edufinance-session",
        tips: "edufinance-tips",
    };

    const defaultUser = {
        name: "Student",
        email: "student@edufinance.com",
        budget: 5000,
        currency: "Birr",
        notifications: true,
        avatarBase64: null,
        theme: "light",
    };

    // Default expenses are generated relative to "today" so charts always have
    // visible structure in the current range for brand-new users.
    const today = new Date();
    const toDateKey = (offsetDays) => {
        const d = new Date(today.getTime() - offsetDays * 86400000);
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    };

    const defaultExpenses = [
        { id: "1", date: toDateKey(1), category: "Food", amount: 120, notes: "Lunch at cafeteria" },
        { id: "2", date: toDateKey(2), category: "Transport", amount: 80, notes: "Bus fare" },
        { id: "3", date: toDateKey(3), category: "Books", amount: 450, notes: "Textbooks for semester" },
        { id: "4", date: toDateKey(4), category: "Entertainment", amount: 200, notes: "Movie with friends" },
        { id: "5", date: toDateKey(5), category: "Food", amount: 95, notes: "Groceries" },
    ];

    const defaultTips = [
        {
            id: "tip-track-daily",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-line-chart">
                <path d="M3 3v18h18"/>
                <path d="m19 9-5 5-4-4-3 3"/>
            </svg>`,
            title: "Track Daily Spending",
            preview: "Record every expense to understand your habits.",
            checklist: [
                "Record all expenses as they happen",
                "Categorize your spending",
                "Review daily totals before bed",
                "Identify patterns in your spending",
            ],
        },
        {
            id: "tip-set-budget",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-target">
                <circle cx="12" cy="12" r="10"/>
                <circle cx="12" cy="12" r="6"/>
                <circle cx="12" cy="12" r="2"/>
            </svg>`,
            title: "Set Budget Goals",
            preview: "Break down monthly goals into daily limits.",
            checklist: [
                "Calculate your monthly budget",
                "Divide into weekly targets",
                "Reserve money for fixed costs",
                "Keep an emergency buffer",
            ],
        },
        {
            id: "tip-meal-plan",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-utensils">
                <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/>
                <path d="M7 2v20"/>
                <path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>
            </svg>`,
            title: "Meal Planning Saves Money",
            preview: "Plan meals to curb impulse purchases.",
            checklist: [
                "Plan meals for the week",
                "Make a shopping list",
                "Cook in batches",
                "Pack lunch instead of buying",
            ],
        },
        {
            id: "tip-transport",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bus">
                <path d="M8 6v6"/>
                <path d="M15 6v6"/>
                <path d="M2 12h19.6"/>
                <path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 7.8 19.1 7 18 7H4a2 2 0 0 0-2 2v10h3"/>
                <circle cx="7" cy="18" r="2"/>
                <path d="M9 18h5"/>
                <circle cx="16" cy="18" r="2"/>
            </svg>`,
            title: "Transportation Tips",
            preview: "Optimize commutes to save on transport costs.",
            checklist: [
                "Use monthly transport passes",
                "Carpool when possible",
                "Walk short distances",
                "Plan efficient routes",
            ],
        },
    ];

    const defaultSplitFriends = [
        { id: "1", name: "Alex", avatar: "👨" },
        { id: "2", name: "Sarah", avatar: "👩" },
        { id: "3", name: "Mike", avatar: "🧑" },
    ];

    const defaultSplitExpenses = [
        {
            id: "1",
            description: "Dinner at restaurant",
            totalAmount: 450,
            paidBy: "me",
            date: "2025-11-20",
            splitBetween: ["me", "1", "2"],
            settled: false,
        },
        {
            id: "2",
            description: "Movie tickets",
            totalAmount: 300,
            paidBy: "3",
            date: "2025-11-19",
            splitBetween: ["me", "3"],
            settled: false,
        },
    ];

    const qs = (selector) => document.querySelector(selector);
    const qsa = (selector) => Array.from(document.querySelectorAll(selector));

    const clone = (value) => JSON.parse(JSON.stringify(value));

    const loadState = (key, fallback) => {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return clone(fallback);
            return JSON.parse(raw);
        } catch (error) {
            console.warn(`Failed to load ${key}`, error);
            return clone(fallback);
        }
    };

    const saveState = (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.warn(`Failed to save ${key}`, error);
        }
    };

    const removeState = (key) => {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.warn(`Failed to remove ${key}`, error);
        }
    };

    const showToast = (message) => {
        const toast = qs("#toast");
        if (!toast) return;
        toast.textContent = message;
        toast.hidden = false;
        clearTimeout(showToast._timeout);
        showToast._timeout = setTimeout(() => {
            toast.hidden = true;
        }, 2400);
    };

    const formatCurrency = (amount, currency) => {
        const formatted = amount.toLocaleString(undefined, {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        });

        if (currency === "Birr" || currency === "ETB") {
            return `${formatted} Birr`;
        }

        const symbol = currency === "USD" ? "$" : currency;
        return `${symbol} ${formatted}`;
    };

    const calculateStats = (expenses) => {
        const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);
        const today = new Date();
        const weekAgo = new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000);
        const thisWeek = expenses.filter((expense) => new Date(expense.date) >= weekAgo);

        return {
            total,
            averageDaily: expenses.length ? total / 7 : 0,
            weekCount: thisWeek.length,
        };
    };

    const updateThemeIcon = (isDark) => {
        const sunIcon = qs("#sunIcon");
        const moonIcon = qs("#moonIcon");
        if (sunIcon && moonIcon) {
            // Show sun icon in dark mode, moon icon in light mode
            sunIcon.style.display = isDark ? "block" : "none";
            moonIcon.style.display = isDark ? "none" : "block";
        }
    };

    const syncTheme = () => {
        const saved = localStorage.getItem(STORAGE_KEYS.theme);
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        const isDark = saved ? saved === "dark" : prefersDark;
        document.documentElement.setAttribute("data-theme", isDark ? "dark" : "light");
        updateThemeIcon(isDark);
    };

    const toggleTheme = () => {
        const current = document.documentElement.getAttribute("data-theme");
        const isDark = current !== "dark";
        document.documentElement.setAttribute("data-theme", isDark ? "dark" : "light");
        localStorage.setItem(STORAGE_KEYS.theme, isDark ? "dark" : "light");
        updateThemeIcon(isDark);
        // Dispatch event for charts to re-render
        window.dispatchEvent(new CustomEvent("themechange", { detail: { theme: isDark ? "dark" : "light" } }));
    };

    const initTheme = () => {
        syncTheme();
        qs("#themeToggle")?.addEventListener("click", toggleTheme);
    };

    // ========== UPDATED AUTHENTICATION FUNCTIONS ==========
    
    // Get session with Firebase support
    const getSession = () => {
        const storedSession = loadState(STORAGE_KEYS.session, { isAuthenticated: false });
        
        // Check Firebase auth state if available
        if (window.Auth?.getCurrentUser) {
            const firebaseUser = Auth.getCurrentUser();
            if (firebaseUser && firebaseUser.uid) {
                return {
                    ...storedSession,
                    isAuthenticated: true,
                    uid: firebaseUser.uid,
                    email: firebaseUser.email,
                    firebaseUser: true,
                    authenticatedAt: new Date().toISOString()
                };
            }
        }
        
        return storedSession;
    };

    // Set session (supports Firebase user data)
    const setSession = (session) => {
        // If we have Firebase user, include that data
        if (window.Auth?.getCurrentUser) {
            const firebaseUser = Auth.getCurrentUser();
            if (firebaseUser) {
                session.uid = firebaseUser.uid;
                session.email = firebaseUser.email;
                session.firebaseUser = true;
            }
        }
        saveState(STORAGE_KEYS.session, session);
    };

    const clearSession = () => removeState(STORAGE_KEYS.session);

    // Check authentication with Firebase support
    const isAuthenticated = () => {
        // First check Firebase
        if (window.Auth?.getCurrentUser) {
            const firebaseUser = Auth.getCurrentUser();
            if (firebaseUser) return true;
        }
        
        // Fallback to localStorage
        const session = getSession();
        return Boolean(session?.isAuthenticated);
    };

    // Require authentication with Firebase support
    const requireAuth = () => {
        if (!isAuthenticated()) {
            window.location.href = "login.html";
            return false;
        }
        return true;
    };

    // Get current user ID (Firebase priority)
    const getCurrentUserId = () => {
        // Try Firebase first
        if (window.Auth?.getCurrentUser) {
            const firebaseUser = Auth.getCurrentUser();
            if (firebaseUser?.uid) {
                return firebaseUser.uid;
            }
        }
        
        // Fallback to localStorage
        const session = getSession();
        return session?.uid || 'local-user';
    };

    // ========== END UPDATED AUTH FUNCTIONS ==========

    // Smooth scrolling to anchor links
    function initSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#' || targetId === '#!') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    
                    // Close mobile menu if open
                    const nav = document.querySelector('.primary-nav');
                    if (nav && nav.classList.contains('is-active')) {
                        document.querySelector('.nav-toggle').click();
                    }
                    
                    // Scroll to the target element
                    const headerOffset = 80; // Adjust this value based on your header height
                    const elementPosition = targetElement.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });

                    // Update URL without adding to history
                    if (history.pushState) {
                        history.pushState(null, null, targetId);
                    } else {
                        location.hash = targetId;
                    }
                }
            });
        });
    }

    const initShellNavigation = () => {
        const navToggle = qs("[data-nav-toggle]");
        const navDrawer = qs("[data-nav-drawer]");
        if (!navDrawer) return;
        const navLinks = Array.from(document.querySelectorAll("[data-nav-link]"));
        const closeNav = () => {
            navDrawer.removeAttribute("data-open");
            navToggle?.setAttribute("aria-expanded", "false");
            document.body.classList.remove("nav-open");
        };
        const openNav = () => {
            navDrawer.setAttribute("data-open", "true");
            navToggle?.setAttribute("aria-expanded", "true");
            document.body.classList.add("nav-open");
        };

        navToggle?.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            if (expanded) {
                closeNav();
            } else {
                openNav();
            }
        });

        window.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                closeNav();
            }
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => closeNav());
        });

        const pageKey = document.body?.dataset?.page;
        if (pageKey) {
            navLinks.forEach((link) => {
                link.classList.toggle("is-active", link.dataset.navLink === pageKey);
            });
        }
    };

    // Updated logout to work with Firebase
    const bindLogoutButton = () => {
        const logoutButton = qs("#logout");
        if (!logoutButton) return;
        
        logoutButton.addEventListener("click", async () => {
            // Sign out from Firebase if available
            if (window.Auth?.signOut) {
                try {
                    await Auth.signOut();
                } catch (error) {
                    console.warn("Firebase sign out error:", error);
                }
            }
            
            // Clear localStorage session
            clearSession();
            
            // Show notification
            showToast("Logged out successfully");
            
            // Redirect to login page
            setTimeout(() => {
                window.location.href = "login.html";
            }, 300);
        });
    };

    const initModal = (overlayId = "modalOverlay", closeId = "modalClose", cancelId = "modalCancel") => {
        const overlay = qs(`#${overlayId}`);
        const closeBtn = qs(`#${closeId}`);
        const cancelBtn = qs(`#${cancelId}`);
        
        const closeModal = () => {
            if (overlay) overlay.hidden = true;
        };
        
        closeBtn?.addEventListener("click", closeModal);
        cancelBtn?.addEventListener("click", closeModal);
        overlay?.addEventListener("click", (event) => {
            if (event.target === overlay) closeModal();
        });
        
        window.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && overlay && !overlay.hidden) {
                closeModal();
            }
        });
        
        return { open: () => { if (overlay) overlay.hidden = false; }, close: closeModal };
    };

    const initPageShell = ({ auth = false } = {}) => {
        initTheme();
        initShellNavigation();
        initSmoothScrolling();
        bindLogoutButton();
        if (auth && !requireAuth()) {
            return false;
        }
        return true;
    };

    const initNavHighlights = ({
        linkSelector = ".nav-links a",
        mobileLinkSelector = ".mobile-menu a",
        sectionSelector = "main section[id]",
        activeClass = "is-active",
    } = {}) => {
        if (!window.IntersectionObserver) return () => {};
        const anchors = [
            ...new Set([
                ...Array.from(document.querySelectorAll(linkSelector) || []),
                ...Array.from(document.querySelectorAll(mobileLinkSelector) || []),
            ]),
        ].filter((anchor) => anchor.hash && document.getElementById(anchor.hash.slice(1)));
        const sections = Array.from(document.querySelectorAll(sectionSelector));
        if (!anchors.length || !sections.length) return () => {};

        const sectionToLinks = new Map();
        anchors.forEach((anchor) => {
            const id = anchor.hash.slice(1);
            const list = sectionToLinks.get(id) || [];
            list.push(anchor);
            sectionToLinks.set(id, list);
        });

        const setActive = (id) => {
            sectionToLinks.forEach((links, key) => {
                links.forEach((link) => {
                    link.classList.toggle(activeClass, key === id);
                });
            });
        };

        const observer = new IntersectionObserver(
            (entries) => {
                const visible = entries
                    .filter((entry) => entry.isIntersecting)
                    .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
                if (!visible.length) return;
                setActive(visible[0].target.id);
            },
            { rootMargin: "-35% 0px -45% 0px", threshold: [0.2, 0.4, 0.6] }
        );

        sections.forEach((section) => observer.observe(section));

        anchors.forEach((anchor) => {
            anchor.addEventListener("click", () => setActive(anchor.hash.slice(1)));
        });

        const initialHash = window.location.hash.slice(1);
        if (initialHash && sectionToLinks.has(initialHash)) {
            setActive(initialHash);
        }
        
        return () => observer.disconnect();
    };

    const App = {
        STORAGE_KEYS,
        defaultUser,
        defaultExpenses,
        defaultTips,
        qs,
        qsa,
        clone,
        loadState,
        saveState,
        removeState,
        showToast,
        formatCurrency,
        calculateStats,
        syncTheme,
        toggleTheme,
        initTheme,
        initNavHighlights,
        initShellNavigation,
        initPageShell,
        initModal,
        initSmoothScrolling,
        getSession,
        setSession,
        clearSession,
        isAuthenticated,
        requireAuth,
        bindLogoutButton,
        getCurrentUserId
    };

    const updatePieChart = (canvasId, data, options = {}) => {
        const canvas = qs(`#${canvasId}`);
        if (!canvas || typeof Chart === "undefined") return null;
        const ctx = canvas.getContext("2d");
        const isDark = document.documentElement.getAttribute("data-theme") === "dark";
        const defaultColors = ["#27ae60", "#f39c12", "#3498db", "#9b59b6", "#e74c3c"];
        const colors = options.colors || defaultColors;
        const labels = data.map((item) => item.label || item.category);
        const values = data.map((item) => item.value || item.amount);
        if (window[`pieChart_${canvasId}`]) {
            window[`pieChart_${canvasId}`].destroy();
        }
        window[`pieChart_${canvasId}`] = new Chart(ctx, {
            type: "pie",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors,
                    borderColor: isDark ? "#34495e" : "#ffffff",
                    borderWidth: 2,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: options.legendPosition || "bottom",
                        labels: { 
                            color: isDark ? "#bdc3c7" : "#7f8c8d",
                            padding: 12,
                        },
                    },
                },
            },
        });
        return window[`pieChart_${canvasId}`];
    };

    App.updatePieChart = updatePieChart;

    window.App = App;
    
    console.log('✅ App module loaded with Firebase support');
})(window);